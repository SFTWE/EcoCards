document.addEventListener("DOMContentLoaded", () => {
  const pontuacao = localStorage.getItem('pontuacao');
  const tempoJogado = localStorage.getItem('tempo');

  if (pontuacao && tempoJogado) {
    document.querySelector('.pontuacao').textContent = `PONTOS: ${pontuacao}`;

    const tempoVitoriaElement = document.querySelector('#tempoVitoria');
    if (tempoVitoriaElement) {
      tempoVitoriaElement.textContent = `TEMPO RESTANTE: ${tempoJogado}`;
    }

    const tempoDerrotaElement = document.querySelector('#tempoDerrota');
    if (tempoDerrotaElement) {
      tempoDerrotaElement.textContent = `TEMPO RESTANTE: ${tempoJogado}`;
    }
  }
});

  